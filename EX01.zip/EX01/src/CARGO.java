public enum CARGO {
    professor,
    Coordenador,
    Secretario,
    Auxiliar;

}
